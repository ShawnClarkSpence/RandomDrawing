@echo off
py writersjumbler_windows.py
pause
