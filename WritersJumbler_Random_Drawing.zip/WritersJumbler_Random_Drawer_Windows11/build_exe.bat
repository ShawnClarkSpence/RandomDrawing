@echo off
py -m PyInstaller --noconfirm --onefile --windowed --name WritersJumblerRandomDrawer writersjumbler_windows.py
echo EXE created in dist\WritersJumblerRandomDrawer.exe
pause
