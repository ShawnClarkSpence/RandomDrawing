import pygame
import random
import datetime
import os
from PIL import Image
from tkinter import Tk, filedialog, colorchooser

pygame.init()
WIDTH, HEIGHT = 1200, 850
DRAWER_H = 185
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("WritersJumbler Random Drawer - Windows 11")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Segoe UI", 18)
small = pygame.font.SysFont("Segoe UI", 15)
bold = pygame.font.SysFont("Segoe UI", 20, bold=True)

BG=(18,18,22); PANEL=(42,45,52); BUTTON=(72,76,86); HOVER=(92,98,112); TEXT=(240,240,245); ACCENT=(0,190,235)
GRID_CHOICES=[20,30,40,50,60,70,80,90,100]

def ask_save(ext, initial):
    root=Tk(); root.withdraw(); root.attributes('-topmost', True)
    path=filedialog.asksaveasfilename(defaultextension='.'+ext, initialfile=initial, filetypes=[(ext.upper()+' files','*.'+ext)])
    root.destroy(); return path

def ask_color(initial, title):
    root = Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    rgb, hex_value = colorchooser.askcolor(color=initial, title=title, parent=root)
    root.destroy()
    if rgb is None:
        return None
    return tuple(int(v) for v in rgb)

class Button:
 def __init__(self,x,y,w,h,text,action): self.rect=pygame.Rect(x,y,w,h);self.text=text;self.action=action
 def draw(self):
  c=HOVER if self.rect.collidepoint(pygame.mouse.get_pos()) else BUTTON;pygame.draw.rect(screen,c,self.rect,border_radius=5);pygame.draw.rect(screen,(120,125,138),self.rect,1,border_radius=5);t=small.render(self.text,True,TEXT);screen.blit(t,t.get_rect(center=self.rect.center))
 def event(self,e):
  if e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and self.rect.collidepoint(e.pos):self.action()

class App:
 def __init__(self):
  self.n=50;self.bg=(0,0,0);self.fg=(0,220,255);self.random_colors=True;self.sym='lr';self.density=6;self.drawer=True;self.cells=[];self.message='Ready';self.reset();self.make_buttons()
 def reset(self):self.cells=[[self.bg for _ in range(self.n)] for __ in range(self.n)]
 def color(self):return tuple(random.randint(20,255) for _ in range(3)) if self.random_colors else tuple(max(0,min(255,v+random.randint(-45,45))) for v in self.fg)
 def mirror(self):
  n=self.n
  if self.sym in ('lr','quad'):
   for r in range(n):
    for c in range(n//2):self.cells[r][n-1-c]=self.cells[r][c]
  elif self.sym=='rl':
   for r in range(n):
    for c in range(n//2):self.cells[r][c]=self.cells[r][n-1-c]
  if self.sym in ('tb','quad'):
   for r in range(n//2):self.cells[n-1-r]=self.cells[r][:]
  elif self.sym=='bt':
   for r in range(n//2):self.cells[r]=self.cells[n-1-r][:]
 def paths(self):
  n=self.n
  for _ in range(self.density):
   r=random.randrange(n);c=random.randrange(max(1,n//2));col=self.color()
   for __ in range(random.randint(max(5,n//5),max(8,n))):
    self.cells[r][c]=col
    if random.random()<.25:
     for rr in range(max(0,r-1),min(n,r+2)):
      for cc in range(max(0,c-1),min(n,c+2)):self.cells[rr][cc]=col
    r=max(0,min(n-1,r+random.choice((-1,0,1))));c=max(0,min(n-1,c+random.choice((-1,0,1))))
  self.mirror();self.message='Random paths added'
 def scatter(self):
  for _ in range(self.density*self.n):self.cells[random.randrange(self.n)][random.randrange(self.n)]=self.color()
  self.mirror();self.message='Random scatter added'
 def bands(self):
  n=self.n
  for _ in range(self.density):
   col=self.color();r=random.randrange(n);start=random.randrange(max(1,n//3));end=random.randrange(max(start+1,n//2),n)
   for rr in range(r,min(n,r+random.randint(1,max(2,n//15)))):
    for c in range(start,end):
     if random.random()<.82:self.cells[rr][c]=col
  self.mirror();self.message='Random bands added'
 def shift(self,dr,dc):
  n=self.n;old=self.cells;self.cells=[[old[(r-dr)%n][(c-dc)%n] for c in range(n)] for r in range(n)];self.message='Drawing moved'
 def blur(self):
  n=self.n;old=[x[:] for x in self.cells]
  for r in range(n):
   for c in range(n):
    ns=[old[rr][cc] for rr in range(max(0,r-1),min(n,r+2)) for cc in range(max(0,c-1),min(n,c+2))];self.cells[r][c]=tuple(sum(x[i] for x in ns)//len(ns) for i in range(3))
  self.message='Blur applied'
 def image(self):
  scale=max(2,1000//self.n);im=Image.new('RGB',(self.n*scale,self.n*scale),self.bg);p=im.load()
  for r in range(self.n):
   for c in range(self.n):
    for y in range(r*scale,(r+1)*scale):
     for x in range(c*scale,(c+1)*scale):p[x,y]=self.cells[r][c]
  return im
 def png(self):
  name='WritersJumbler_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.png';p=ask_save('png',name)
  if p:self.image().save(p);self.message='PNG saved'
 def gif(self):
  name='WritersJumbler_Move_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.gif';p=ask_save('gif',name)
  if not p:return
  d={'N':(-1,0),'S':(1,0),'E':(0,1),'W':(0,-1)}[self.gif_dir];original=[x[:] for x in self.cells];frames=[]
  for _ in range(self.n):self.shift(*d);frames.append(self.image())
  self.cells=original;frames[0].save(p,save_all=True,append_images=frames[1:],duration=self.gif_speed,loop=0);self.message='Moving GIF saved'
 def grid_next(self):
  i=(GRID_CHOICES.index(self.n)+1)%len(GRID_CHOICES);self.n=GRID_CHOICES[i];self.reset();self.message=f'Grid {self.n} x {self.n}'
 def sym_next(self):
  x=['lr','rl','tb','bt','quad','none'];self.sym=x[(x.index(self.sym)+1)%len(x)]
 def density_up(self):self.density=min(30,self.density+1)
 def density_down(self):self.density=max(1,self.density-1)
 def speed_up(self):self.gif_speed=min(500,self.gif_speed+10)
 def speed_down(self):self.gif_speed=max(20,self.gif_speed-10)
 def dir_next(self):self.gif_dir={'N':'S','S':'E','E':'W','W':'N'}[self.gif_dir]
 def colors(self):
  self.random_colors=not self.random_colors
  self.message='Random colors: '+('ON' if self.random_colors else 'OFF')
 def pick_fg(self):
  chosen=ask_color(self.fg,'Choose WritersJumbler Main Color')
  if chosen is not None:
   self.fg=chosen;self.random_colors=False;self.message='Main color selected; Random Colors OFF'
 def pick_bg(self):
  chosen=ask_color(self.bg,'Choose WritersJumbler Background Color')
  if chosen is not None:
   old=self.bg;self.bg=chosen
   # Preserve artwork while replacing cells that were still the old background.
   for r in range(self.n):
    for c in range(self.n):
     if self.cells[r][c]==old:self.cells[r][c]=chosen
   self.message='Background color selected'
 def toggle(self):self.drawer=not self.drawer
 def make_buttons(self):
  self.gif_dir='E';self.gif_speed=80
  self.toggle_btn=Button(8,7,170,30,'Hide Options',self.toggle)
  labels=[('Grid Size',self.grid_next),('Symmetry',self.sym_next),('FG Color',self.pick_fg),('BG Color',self.pick_bg),('Random Colors',self.colors),('Density -',self.density_down),('Density +',self.density_up),('Random Paths',self.paths),('Scatter',self.scatter),('Bands',self.bands),('Blur',self.blur),('Clear',self.reset),('N',lambda:self.shift(-1,0)),('S',lambda:self.shift(1,0)),('W',lambda:self.shift(0,-1)),('E',lambda:self.shift(0,1)),('Save PNG',self.png),('GIF Direction',self.dir_next),('GIF Speed -',self.speed_down),('GIF Speed +',self.speed_up),('Save Moving GIF',self.gif)]
  self.buttons=[]
  for i,(t,a) in enumerate(labels):self.buttons.append(Button(10+(i%11)*106,48+(i//11)*45,98,34,t,a))
 def event(self,e):
  self.toggle_btn.event(e)
  if self.drawer:
   for b in self.buttons:b.event(e)
 def draw(self):
  w,h=screen.get_size();screen.fill(BG);bar=DRAWER_H if self.drawer else 45
  pygame.draw.rect(screen,PANEL,(0,0,w,bar));self.toggle_btn.text='Hide Options' if self.drawer else 'Show Options';self.toggle_btn.draw()
  screen.blit(bold.render('WritersJumbler Random Drawer',True,TEXT),(195,10))
  if self.drawer:
   for b in self.buttons:b.draw()
   info=f'Grid: {self.n}x{self.n}   Symmetry: {self.sym}   Density: {self.density}   Random colors: {self.random_colors}   GIF: {self.gif_dir} / {self.gif_speed}ms'
   screen.blit(small.render(info,True,TEXT),(12,143));screen.blit(small.render(self.message,True,ACCENT),(12,164))
  top=bar+5;area_h=max(1,h-top-5);cw=w/self.n;ch=area_h/self.n
  for r,row in enumerate(self.cells):
   for c,col in enumerate(row):pygame.draw.rect(screen,col,(int(c*cw),top+int(r*ch),max(1,int(cw)-1),max(1,int(ch)-1)))
  pygame.display.flip()

app=App();running=True
while running:
 for event in pygame.event.get():
  if event.type==pygame.QUIT:running=False
  elif event.type==pygame.VIDEORESIZE:screen=pygame.display.set_mode(event.size,pygame.RESIZABLE)
  else:app.event(event)
 app.draw();clock.tick(30)
pygame.quit()
