WritersJumbler Random Drawer - Windows 11

This edition uses one Pygame window with an integrated title/options drawer. GTK and Glade are not required on Windows.

INSTALL
1. Install Python 3 for Windows and enable Add Python to PATH.
2. Double-click install_windows.bat.
3. Double-click run_windows.bat.

BUILD EXE
Double-click build_exe.bat. The result is dist\WritersJumblerRandomDrawer.exe.

FEATURES
- Integrated collapsible options drawer
- Grid sizes 20 through 100
- Random Paths, Scatter, Bands
- Symmetry, density, random colors
- N/S/E/W drawing movement
- PNG export
- N/S/E/W moving GIF export and speed control

COLOR PICKERS
- FG Color opens the Windows/Tk color chooser and sets the main drawing color.
- BG Color opens the color chooser and changes the background color.
- Choosing FG Color automatically switches Random Colors OFF so new generated art uses the chosen foreground family.
- Random Colors toggles fully random generated colors back on/off.
